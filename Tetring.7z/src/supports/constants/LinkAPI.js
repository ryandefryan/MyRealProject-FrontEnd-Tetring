const LinkAPI = 'http://localhost:4000/'

export default LinkAPI